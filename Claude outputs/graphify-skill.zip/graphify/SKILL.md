---
name: graphify
description: Map a codebase or project folder into a knowledge graph (graphify CLI) and query it — use for architecture questions, finding where something lives, or tracing how two parts connect.
---

# graphify (Cowork edition)

Wrapper around the open-source graphify CLI (PyPI package `graphifyy`, double y; repo github.com/Graphify-Labs/graphify). Code is parsed locally with tree-sitter: no LLM, no API key. Never ask the user for an API key.

## When to use
- Questions about project structure: "где обрабатывается X", "что вызывает Y", "как связаны сайт и бот".
- Before a large change: find every function that touches an endpoint, table or helper.
- Do NOT use for a one-file question; just read the file.

## Steps
1. Install (cloud container, once per session): `pip install -q graphifyy --break-system-packages` (add `"graphifyy[sql]"` if .sql files matter).
2. Get the code into the container. User folders may be iCloud-offloaded ("Resource deadlock avoided" in device_bash). Then list the folder with device_list_dir (recursive), skip .git/.wrangler/node_modules/media, stage only source files (js/ts/py/html/sql/toml/md) with device_stage_files, copy them to /home/claude/gwork/<name>/ (uploads dir is read-only). For a GitHub repo: `graphify clone <url>`.
3. Build:
   cd /home/claude/gwork/<name>
   graphify update . --no-cluster
   graphify cluster-only . --no-label
   Output: graphify-out/graph.json, GRAPH_REPORT.md, graph.html
4. Read graphify-out/GRAPH_REPORT.md first, then query instead of grepping:
   graphify query "<question>"   |   graphify explain "<node>"   |   graphify path "A" "B"
   Edges are tagged EXTRACTED (explicit in code) vs INFERRED.
5. Several repos: build each, then `graphify merge-graphs a/graphify-out/graph.json b/graphify-out/graph.json --out merged/graph.json`.
6. After code changes: `graphify update .` (incremental).

## Delivering
- Answer with file:line references; open the source to confirm before claiming a bug.
- To show the map: SendUserFile graph.html.
- Don't write graphify-out/ into the user's repo unless asked; if asked, add it to .gitignore.

## Limits
- Docs/PDF/images need a semantic LLM pass; skip unless asked.
- The graph is a map, not proof: verify in the file before editing.
